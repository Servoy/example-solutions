$scope.api.drawGraph = function(node) {
	$scope.model.node = node;
}